package id.mangayomi.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.Charset

private const val REPO_URL = "https://github.com/keiyoushi/extensions/raw/repo/index.pb"

data class RepoItem(val title: String, val details: String, val raw: String = "")

/**
 * Generic protobuf wire-format reader.
 * It safely walks protobuf fields without assuming the repository schema.
 * Length-delimited fields are shown as UTF-8 only when they look like text;
 * nested messages are recursively inspected for readable metadata.
 */
private object ProtoReader {
    data class Field(val number: Int, val wire: Int, val value: Long = 0, val bytes: ByteArray? = null)

    fun fields(data: ByteArray): List<Field> {
        val out = mutableListOf<Field>()
        var p = 0
        fun varint(): Long {
            var result = 0L
            var shift = 0
            while (p < data.size && shift < 64) {
                val b = data[p++].toInt() and 0xff
                result = result or ((b and 0x7f).toLong() shl shift)
                if ((b and 0x80) == 0) return result
                shift += 7
            }
            throw IllegalArgumentException("Protobuf varint tidak valid")
        }
        while (p < data.size) {
            val tag = varint().toInt()
            if (tag == 0) break
            val number = tag ushr 3
            val wire = tag and 7
            when (wire) {
                0 -> out += Field(number, wire, value = varint())
                1 -> {
                    if (p + 8 > data.size) break
                    var v = 0L
                    for (i in 0..7) v = v or ((data[p++].toLong() and 0xff) shl (8 * i))
                    out += Field(number, wire, value = v)
                }
                2 -> {
                    val len = varint().toInt()
                    if (len < 0 || p + len > data.size) break
                    val b = data.copyOfRange(p, p + len); p += len
                    out += Field(number, wire, bytes = b)
                }
                5 -> {
                    if (p + 4 > data.size) break
                    var v = 0L
                    for (i in 0..3) v = v or ((data[p++].toLong() and 0xff) shl (8 * i))
                    out += Field(number, wire, value = v)
                }
                else -> throw IllegalArgumentException("Tipe field protobuf tidak didukung: $wire")
            }
        }
        return out
    }

    private fun cleanText(bytes: ByteArray): String? {
        if (bytes.isEmpty()) return null
        val s = bytes.toString(Charset.forName("UTF-8")).trim()
        if (s.isEmpty() || s.any { it == '\u0000' || (it.isISOControl() && it != '\n' && it != '\r' && it != '\t') }) return null
        return s.takeIf { it.length < 1200 }
    }

    fun extractMessages(data: ByteArray, depth: Int = 0): List<RepoItem> {
        if (depth > 5) return emptyList()
        val result = mutableListOf<RepoItem>()
        val fs = try { fields(data) } catch (_: Exception) { return result }
        val strings = fs.mapNotNull { f -> if (f.wire == 2) f.bytes?.let(::cleanText)?.let { f.number to it } else null }
        val nested = fs.filter { it.wire == 2 && it.bytes != null }
        val joined = strings.filter { (_, s) -> s.startsWith("http") || s.contains(".apk") || s.contains("tachiyomi") || s.contains("mihon") || s.contains("extension") || s.contains("en") || s.contains("id") }
        if (nested.isNotEmpty() && (joined.isNotEmpty() || depth > 0)) {
            val display = joined.take(8).joinToString("\n") { "Field ${it.first}: ${it.second}" }
            if (display.isNotBlank()) result += RepoItem("Entri repository #${result.size + 1}", display, display)
        }
        nested.forEach { f ->
            val b = f.bytes ?: return@forEach
            // Avoid interpreting long arbitrary APK payloads as nested metadata.
            if (b.size <= 200_000) result += extractMessages(b, depth + 1)
        }
        return result
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MangaYomiApp() }
    }
}

@Composable
private fun MangaYomiApp() {
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Repository belum dimuat.") }
    var items by remember { mutableStateOf(emptyList<RepoItem>()) }
    var rawSize by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    val colors = darkColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFFB9A0FF),
        background = androidx.compose.ui.graphics.Color(0xFF111116),
        surface = androidx.compose.ui.graphics.Color(0xFF1B1B23)
    )
    MaterialTheme(colorScheme = colors) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().padding(18.dp)) {
                Text("Manga Yomi", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Extension Repository", color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(16.dp))
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Keiyoushi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(5.dp))
                        Text(REPO_URL, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = {
                            loading = true
                            status = "Mengunduh index.pb…"
                            items = emptyList()
                            kotlinx.coroutines.MainScope().launch {
                                try {
                                    val bytes = withContext(Dispatchers.IO) {
                                        val c = URL(REPO_URL).openConnection() as HttpURLConnection
                                        c.requestMethod = "GET"
                                        c.connectTimeout = 15000
                                        c.readTimeout = 20000
                                        c.setRequestProperty("User-Agent", "MangaYomi/0.1")
                                        try {
                                            if (c.responseCode !in 200..299) throw IllegalStateException("HTTP ${c.responseCode}")
                                            c.inputStream.use { it.readBytes() }
                                        } finally { c.disconnect() }
                                    }
                                    rawSize = bytes.size
                                    val parsed = withContext(Dispatchers.Default) { ProtoReader.extractMessages(bytes) }
                                    items = parsed.distinctBy { it.raw }
                                    status = if (parsed.isEmpty())
                                        "index.pb berhasil diunduh (${bytes.size} byte), tetapi skema repository belum dipetakan sepenuhnya. Belum ada extension yang ditampilkan."
                                    else "index.pb diunduh (${bytes.size} byte). Data berikut adalah hasil pembacaan protobuf generik, bukan daftar extension terverifikasi."
                                } catch (e: Exception) {
                                    status = "Gagal memuat repository: ${e.message ?: "kesalahan jaringan"}"
                                } finally { loading = false }
                            }
                        }, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                            Text(if (loading) "Memuat…" else "Muat repository")
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Cari data yang terbaca") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(8.dp))
                if (items.isEmpty() && !loading) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("Data repository akan tampil di sini setelah dimuat.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        items(items.filter { it.title.contains(query, true) || it.details.contains(query, true) }) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(item.title, fontWeight = FontWeight.SemiBold)
                                    Spacer(Modifier.height(5.dp))
                                    Text(item.details, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
                Text("Tahap awal: membaca index.pb. APK extension Mihon tidak dapat dijalankan langsung oleh aplikasi ini tanpa lapisan kompatibilitas Android.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
